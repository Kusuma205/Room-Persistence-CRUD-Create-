package com.example.test_roompersistence.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.example.test_roompersistence.room.NoteDatabase
import com.example.test_roompersistence.room.NoteRepository

class NoteViewModel (application: Application) :AndroidViewModel(application){
    private val repository: NoteRepository
    val allnotes: LiveData<List<Note>>

    init {
        val noteDao = NoteDatabase.getDatabase(aplication).noteDao()

    }

}